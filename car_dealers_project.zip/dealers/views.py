
from django.shortcuts import render
from .models import Dealer

def home(request):
    dealers = Dealer.objects.all()
    return render(request, 'home.html', {'dealers': dealers})
